<?php echo e($slot); ?>

<?php /**PATH E:\projek 8 m\bulava\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>