<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\projek 8 m\bulava\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>