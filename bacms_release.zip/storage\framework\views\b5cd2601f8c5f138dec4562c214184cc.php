<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Riwayat Pertandingan'); ?>

    <div class="card custom-card p-4 mb-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
            <div>
                <h4 class="fw-bold text-dark mb-1"><i class="bi bi-award-fill me-2 text-danger"></i>Riwayat Pertandingan</h4>
                <p class="text-muted mb-0" style="font-size: 0.9rem;">Daftar seluruh kejuaraan dan kompetisi yang telah Anda ikuti</p>
            </div>
            <!-- Trigger button for Modal -->
            <button type="button" class="btn btn-primary shadow px-4 py-2.5" data-bs-toggle="modal" data-bs-target="#addResultModal">
                <i class="bi bi-plus-circle me-2"></i> Tambah Hasil Pertandingan
            </button>
        </div>

        <div class="table-responsive">
            <table id="resultsTable" class="table table-hover align-middle" style="width: 100%;">
                <thead>
                    <tr class="text-muted" style="font-size: 0.875rem;">
                        <th>Tanggal</th>
                        <th>Event / Lomba</th>
                        <th>Lokasi</th>
                        <th class="text-center">Score</th>
                        <th class="text-end" style="padding-right: 20px;">Hasil Pertandingan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="fw-bold text-dark"><?php echo e(\Carbon\Carbon::parse($res->tanggal)->translatedFormat('d F Y')); ?></div>
                            </td>
                            <td>
                                <span class="fw-bold text-dark" style="font-size: 0.95rem;"><?php echo e($res->event_name); ?></span>
                            </td>
                            <td>
                                <span class="text-muted"><i class="bi bi-geo-alt-fill me-1"></i> <?php echo e($res->lokasi); ?></span>
                            </td>
                            <td class="text-center fw-extrabold text-danger fs-5"><?php echo e($res->score); ?></td>
                            <td class="text-end" style="padding-right: 20px;">
                                <?php if($res->hasil_pertandingan === 'Juara 1'): ?>
                                    <span class="badge bg-warning text-dark px-3 py-2 border border-warning" style="font-size: 0.8rem; font-weight: 600;">
                                        <i class="bi bi-trophy-fill me-1"></i> Juara 1 (Emas)
                                    </span>
                                <?php elseif($res->hasil_pertandingan === 'Juara 2'): ?>
                                    <span class="badge bg-light text-secondary px-3 py-2 border" style="font-size: 0.8rem; font-weight: 600;">
                                        <i class="bi bi-trophy-fill me-1"></i> Juara 2 (Perak)
                                    </span>
                                <?php elseif($res->hasil_pertandingan === 'Juara 3'): ?>
                                    <span class="badge px-3 py-2 border" style="font-size: 0.8rem; font-weight: 600; background-color: #fce8e6; color: #a94442;">
                                        <i class="bi bi-trophy-fill me-1"></i> Juara 3 (Perunggu)
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-light text-muted px-3 py-2 border" style="font-size: 0.8rem; font-weight: 500;">
                                        Tidak Juara
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- BOOTSTRAP MODAL FOR ADDING RESULT -->
    <div class="modal fade" id="addResultModal" tabindex="-1" aria-labelledby="addResultModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content border-0 rounded-4 shadow">
                <div class="modal-header border-bottom p-3">
                    <h5 class="modal-title fw-bold text-dark" id="addResultModalLabel">
                        <i class="bi bi-trophy me-2 text-danger"></i> Catat Hasil Pertandingan
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <form action="<?php echo e(route('results.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <div class="modal-body p-3">
                        <!-- Event Name -->
                        <div class="mb-3">
                            <label for="event_name" class="form-label fw-semibold" style="font-size: 0.9rem;">Nama Event / Lomba</label>
                            <input type="text" class="form-control bg-light <?php $__errorArgs = ['event_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="event_name" name="event_name" required placeholder="Contoh: Kejuaraan Bandung Open 2026" value="<?php echo e(old('event_name')); ?>">
                        </div>

                        <!-- Location -->
                        <div class="mb-3">
                            <label for="lokasi" class="form-label fw-semibold" style="font-size: 0.9rem;">Lokasi</label>
                            <input type="text" class="form-control bg-light <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lokasi" name="lokasi" required placeholder="Contoh: GOR Pajajaran, Bandung" value="<?php echo e(old('lokasi')); ?>">
                        </div>

                        <div class="row mb-3">
                            <!-- Date -->
                            <div class="col-6">
                                <label for="tanggal" class="form-label fw-semibold" style="font-size: 0.9rem;">Tanggal</label>
                                <input type="date" class="form-control bg-light <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal" name="tanggal" required value="<?php echo e(old('tanggal', date('Y-m-d'))); ?>">
                            </div>
                            <!-- Score -->
                            <div class="col-6">
                                <label for="score" class="form-label fw-semibold" style="font-size: 0.9rem;">Score</label>
                                <input type="number" class="form-control bg-light <?php $__errorArgs = ['score'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="score" name="score" required min="0" max="1000" placeholder="Skor Anda" value="<?php echo e(old('score')); ?>">
                            </div>
                        </div>

                        <!-- Hasil Pertandingan -->
                        <div class="mb-2">
                            <label for="hasil_pertandingan" class="form-label fw-semibold" style="font-size: 0.9rem;">Hasil Pertandingan</label>
                            <select class="form-select bg-light <?php $__errorArgs = ['hasil_pertandingan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="hasil_pertandingan" name="hasil_pertandingan" required>
                                <option value="" disabled selected>Pilih Hasil</option>
                                <option value="Tidak Juara" <?php echo e(old('hasil_pertandingan') == 'Tidak Juara' ? 'selected' : ''); ?>>Tidak Juara</option>
                                <option value="Juara 1" <?php echo e(old('hasil_pertandingan') == 'Juara 1' ? 'selected' : ''); ?>>Juara 1 (Emas)</option>
                                <option value="Juara 2" <?php echo e(old('hasil_pertandingan') == 'Juara 2' ? 'selected' : ''); ?>>Juara 2 (Perak)</option>
                                <option value="Juara 3" <?php echo e(old('hasil_pertandingan') == 'Juara 3' ? 'selected' : ''); ?>>Juara 3 (Perunggu)</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="modal-footer border-top p-3 d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-light px-4 py-2 border" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary px-5 py-2 shadow">
                            Simpan Hasil <i class="bi bi-save ms-1"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
        <script>
            $(document).ready(function() {
                // Initialize DataTable
                $('#resultsTable').DataTable({
                    language: {
                        url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/id.json'
                    },
                    responsive: true,
                    pageLength: 10,
                    order: [[0, 'desc']] // Order by Date descending
                });

                // Show modal automatically if validation errors occurred
                <?php if($errors->any()): ?>
                    var myModal = new bootstrap.Modal(document.getElementById('addResultModal'));
                    myModal.show();
                <?php endif; ?>
            });
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\projek 8 m\bulava\resources\views/results/index.blade.php ENDPATH**/ ?>